#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "definitions.h"
#include "my_drivers/ring_buffer/ring_buffer.h"

#define WIFI_SSID "Galaxie"
#define WIFI_PASS "vzga8484"
#define FINNHUB_API_KEY "d100501r01qkepd2tfegd100501r01qkepd2tff0"

#define NEXTION_T0  0  
#define NEXTION_T1  1 
#define NEXTION_T2  2  
#define NEXTION_T3  3 
#define NEXTION_T4  4 
#define NEXTION_T5  5  
#define NEXTION_T6  6  
#define NEXTION_T7  7  
#define NEXTION_T8  8  
#define NEXTION_T10 10 
#define NEXTION_T11 11 

const char* symbols[] = {"AAPL", "MSFT", "TSLA", "NVDA"};

ring_buffer_t rb;
uint8_t rb_buffer[512];
volatile uint8_t rb_char;
 
volatile uint8_t tc_flag = 0;
volatile uint8_t stock_update_flag = 0;

void zapis_na_display(uint8_t txt_index, const char* txt) {
    char msg[64];
    int length = sprintf(msg, "t%u.txt=\"%s\"", txt_index, txt);
    msg[length++] = 0xFF;
    msg[length++] = 0xFF;
    msg[length++] = 0xFF;
    SERCOM3_USART_Write((uint8_t*)msg, length);
    while(SERCOM3_USART_WriteIsBusy());
}

void esp_rx_callback(uintptr_t context) {
    ring_buffer_write((ring_buffer_t*)context, rb_char);
    uint8_t temp_char = rb_char;  
    SERCOM4_USART_Read((void*)&temp_char, 1);
    rb_char = temp_char;
}

void tc_callback(TC_TIMER_STATUS status, uintptr_t context) {
    tc_flag = 1;
    static uint16_t counter = 0;
    if (++counter >= 300) {  
        stock_update_flag = 1;
        counter = 0;
    }
}

void delay(uint16_t ms) {
    SYSTICK_TimerStart();
    SYSTICK_DelayMs(ms);
    SYSTICK_TimerStop();
}

void esp_write(const char* str) {
    SERCOM4_USART_Write((uint8_t*)str, strlen(str));
    while(SERCOM4_USART_WriteIsBusy());
}

typedef struct {
    char price[16];
    char percent[16];
} stock_data_t;

void parse_stock_data(const char* data, stock_data_t* stock) {
    const char* c_ptr = strstr(data, "\"c\":");
    const char* dp_ptr = strstr(data, "\"dp\":");
    
    if(c_ptr && dp_ptr) {
        sscanf(c_ptr + 4, "%15[^,}]", stock->price);
        sscanf(dp_ptr + 5, "%15[^,}]", stock->percent);
    } else {
        strcpy(stock->price, "ERR");
        strcpy(stock->percent, "ERR");
    }
}

void esp_send_http_request(const char* symbol) {
    char http_get[256];
    sprintf(http_get,
        "GET /api/v1/quote?symbol=%s&token=%s HTTP/1.1\r\n"
        "Host: finnhub.io\r\n"
        "Connection: close\r\n\r\n",
        symbol, FINNHUB_API_KEY);

    esp_write("AT+CIPSTART=\"TCP\",\"finnhub.io\",80\r\n");
    delay(2000);

    char cipsend[32];
    sprintf(cipsend, "AT+CIPSEND=%u\r\n", (unsigned)strlen(http_get));
    esp_write(cipsend);
    delay(1000);

    esp_write(http_get);
    delay(4000);
}

bool get_json_response(char* buffer, size_t max_len) {
    size_t buf_i = 0;
    bool json_started = false;
    uint32_t wait_time = 0;

    while(wait_time < 5000) {  
        while(!ring_buffer_is_empty(&rb)) {
            uint8_t c = 0;  
            ring_buffer_read(&rb, &c);

            if(c == '{') json_started = true;
            if(json_started) {
                if(buf_i < (max_len - 1)) {
                    buffer[buf_i++] = c;
                }
                if(c == '}') {
                    buffer[buf_i] = '\0';
                    return true;
                }
            }
        }
        delay(10);
        wait_time += 10;
        SYS_Tasks();
    }
    return false;
}

void update_stock_data() {
    stock_data_t stocks[4];
    
    for(int i = 0; i < 4; i++) {
        esp_send_http_request(symbols[i]);
        
        char json_buf[256];
        bool got_json = get_json_response(json_buf, sizeof(json_buf));
        
        if(got_json) {
            parse_stock_data(json_buf, &stocks[i]);
        } else {
            strcpy(stocks[i].price, "N/A");
            strcpy(stocks[i].percent, "N/A");
        }
    }
    
    zapis_na_display(NEXTION_T3, stocks[0].price);
    zapis_na_display(NEXTION_T4, stocks[0].percent);
    zapis_na_display(NEXTION_T5, stocks[1].price);
    zapis_na_display(NEXTION_T6, stocks[1].percent);
    zapis_na_display(NEXTION_T7, stocks[2].price);
    zapis_na_display(NEXTION_T8, stocks[2].percent);
    zapis_na_display(NEXTION_T10, stocks[3].price);
    zapis_na_display(NEXTION_T11, stocks[3].percent);
}

int main(void) {
    SYS_Initialize(NULL);
    SERCOM4_USART_ReceiverDisable();
    
    ring_buffer_init(&rb, rb_buffer, sizeof(rb_buffer));
    SERCOM4_USART_ReadCallbackRegister(esp_rx_callback, (uintptr_t)&rb);
   
    uint8_t temp_char = 0;
    SERCOM4_USART_Read((void*)&temp_char, 1);
    rb_char = temp_char;
    
    TC0_TimerCallbackRegister(tc_callback, (uintptr_t)NULL);
    TC0_TimerStart();
    
    delay(3000);
    esp_write("ATE0\r\n");
    delay(100);
    esp_write("AT+CWMODE=1\r\n");
    delay(100);
    
    char cmd[128];
    sprintf(cmd, "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PASS);
    esp_write(cmd);
    delay(5000);
    
    esp_write("AT+CIPSNTPCFG=1,2,\"pool.ntp.org\"\r\n");
    delay(2000);
    
    SERCOM4_USART_ReceiverEnable();
    
    zapis_na_display(NEXTION_T0, "--");
    zapis_na_display(NEXTION_T1, "--");
    zapis_na_display(NEXTION_T2, "--");
    zapis_na_display(NEXTION_T3, "--");
    zapis_na_display(NEXTION_T4, "--");
    zapis_na_display(NEXTION_T5, "--");
    zapis_na_display(NEXTION_T6, "--");
    zapis_na_display(NEXTION_T7, "--");
    zapis_na_display(NEXTION_T8, "--");
    zapis_na_display(NEXTION_T10, "--");
    zapis_na_display(NEXTION_T11, "--");
    
    update_stock_data();

    while(1) {
        if(tc_flag) {
            tc_flag = 0;
            
            struct tm current_time;
            RTC_RTCCTimeGet(&current_time);
            
            char time_str[3];
            sprintf(time_str, "%02u", current_time.tm_hour);
            zapis_na_display(NEXTION_T0, time_str);
            
            sprintf(time_str, "%02u", current_time.tm_min);
            zapis_na_display(NEXTION_T1, time_str);
            
            sprintf(time_str, "%02u", current_time.tm_sec);
            zapis_na_display(NEXTION_T2, time_str);
        }

        if(stock_update_flag) {
            stock_update_flag = 0;
            update_stock_data();
        }
        
        SYS_Tasks();
    }

    return (EXIT_FAILURE);
}